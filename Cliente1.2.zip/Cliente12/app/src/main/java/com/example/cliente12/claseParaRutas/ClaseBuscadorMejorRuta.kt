package com.example.cliente12.claseParaRutas

import android.app.Application
import android.content.Context
import android.location.Location
import android.net.ConnectivityManager
import android.net.Network
import android.os.AsyncTask
import android.net.NetworkInfo
import java.io.IOException


class ClaseBuscadorMejorRuta {

    lateinit var UbicacionesDeKerkly: Array<Location>
    var  origenRuta: Int?=0
    var  finalRuta: Int? =0
    var datosOrgien: Double?=0.0
    var datosDestino: Double?=0.0




    private class CreandoObjetosLocation : AsyncTask<String?, String?, String?>() {
        override fun doInBackground(vararg params: String?): String? {
            val puntoOrigenCliente: Location
            val puntoDeKerkly: Location

            val context: Context
            context = Application()

            val manager =
                context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val networkInfo = manager.activeNetworkInfo
            if (networkInfo != null) {
                if (networkInfo.getState() == NetworkInfo.State.CONNECTED) {
                    // CONNECTED
                      /*  try {
                            puntoOrigenCliente = claseLocation.busca(direccionOrigen)
                            if(puntoOrigenCliente == null){
                                return "no hay ningun origen"
                            }

                        }catch (e: IOException){

                        }*/

                }

            } else {
                return "No hay conexion a internet"
                // DISCONNECTED"
            }
            return null
        }
    }


}
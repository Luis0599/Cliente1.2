package com.example.cliente12.claseParaRutas

import android.location.Location

class ClaseRutaAsignar {

    fun datoskerkly(): Location? {
       var ubicacionKerkly: Location
        val myArray  = arrayOf(17.5364664, -99.4958669, 17.543049, -99.5188493)
        //ubicacionKerkly
        return null
    }


}
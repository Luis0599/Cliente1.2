package com.example.cliente12.claseParaRutas

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class ModeloRutas {
   // @SerializedName("laltud")
    //@Expose
    var latitud =0.0
    var longitud =0.0
}
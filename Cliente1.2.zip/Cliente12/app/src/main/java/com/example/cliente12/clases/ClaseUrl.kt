package com.example.cliente12.clases

class ClaseUrl {
    val ROOT_URL = "https://5d8d-189-143-97-132.ngrok.io"+"/Kerkly/cliente"
}